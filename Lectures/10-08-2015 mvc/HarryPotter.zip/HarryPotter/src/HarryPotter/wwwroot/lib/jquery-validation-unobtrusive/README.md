jQuery Unobtrusive Validation
=============================

The jQuery Unobtrusive Validation library complements jQuery Validation by adding support for specifying validation options as HTML5 `data-*` elements.

This project is part of ASP.NET vNext. You can find samples, documentation and getting started instructions for ASP.NET vNext at the [Home](https://github.com/aspnet/home) repo.

