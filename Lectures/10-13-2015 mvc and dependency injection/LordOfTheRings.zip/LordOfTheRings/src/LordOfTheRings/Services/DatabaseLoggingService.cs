﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LordOfTheRings.Services
{
	public class DatabaseLoggingService : ILoggingService
	{
		public void Log(string message)
		{
			// we write to the database here
		}
	}
}
